#Setup Script
from setuptools import setup

setup(
    name = 'Pradyut_CatsvsDogs',
    version = '0.0.1',
    include_package_data = False,
    scripts = ['prediction.py']
)